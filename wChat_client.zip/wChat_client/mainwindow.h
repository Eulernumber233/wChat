#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "logindialog.h"
#include "registdialog.h"
#include "resetdialog.h"
#include "chatdialog.h"
#include "tcpmgr.h"
QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
public slots:
    void slotSwitchRegist();// 登录窗口切换注册窗口
    void slotSwitchLogin(); // 注册窗口返回登录窗口
    void slotSwitchReset(); // 登录窗口切换找回密码窗口
    void slotSwitchLogin2();// 找回密码窗口返回登录窗口
    void slotSwitchchat();
private:
    Ui::MainWindow *ui;
    LoginDialog*_login_dlg;
    RegistDialog* _regist_dlg;
    ResetDialog* _reset_dlg;
    ChatDialog* _chat_dlg;
};
#endif // MAINWINDOW_H
