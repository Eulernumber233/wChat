#ifndef CONTACTUSERLIST_H
#define CONTACTUSERLIST_H

// 联系人列表

#include <QListWidget>
#include <QEvent>
#include <QWheelEvent>
#include <QScrollEvent>
#include <QDebug>
#include <memory>
#include "userdata.h"
#include "usermgr.h"

class ConUserItem;
class ContactUserList : public QListWidget
{
    Q_OBJECT
public:
    ContactUserList(QWidget *parent = nullptr);
    void ShowRedPoint(bool bshow = true);
protected:
    bool eventFilter(QObject *watched, QEvent *event) override ;
private:
    void addContactUserList();
public slots:
    void slot_item_clicked(QListWidgetItem *item);
    void slot_add_auth_firend(std::shared_ptr<AuthInfo>);//链接对端同意认证后通知的信号
    void slot_auth_rsp(std::shared_ptr<AuthRsp>);//链接自己点击同意认证后界面刷新
signals:
    void sig_loading_contact_user();
    void sig_switch_apply_friend_page();
    void sig_switch_friend_info_page(std::shared_ptr<UserInfo>);
private:
    ConUserItem* _add_friend_item;
    QListWidgetItem * _groupitem;
    bool _load_pending;
};

#endif // CONTACTUSERLIST_H
